setwd("/Users/srishteesinha/Documents")
getwd()

install.packages("tidytext")
library("tidytext")

install.packages("tm")
library("tm")

install.packages("topicmodels")
library("topicmodels")

# Load data
thrive_data <- read.csv("WhatIsNeededToThrive.csv", header = TRUE) 

# Examine data 
head(thrive_data)
str(thrive_data)
summary(thrive_data)

# Create document-term matrix for text mining
docs <- Corpus(VectorSource(thrive_data))
dtm_thrive <- DocumentTermMatrix(docs, control = list(lemma=TRUE,removePunctuation = TRUE,
                                                     removeNumbers = TRUE, stopwords = TRUE,
                                                     tolower = TRUE))
# Create corpus
corpus <- VCorpus(VectorSource(thrive_data)) 

# Clean text 
corpus <- tm_map(corpus, content_transformer(tolower))
corpus <- tm_map(corpus, removeNumbers)
corpus <- tm_map(corpus, removeWords, stopwords("english"))
corpus <- tm_map(corpus, stripWhitespace)


# Build term-document matrix
tdm <- TermDocumentMatrix(corpus)
freqs <- colSums(as.matrix(tdm))
freqs <- sort(freqs, decreasing=TRUE)

# Extract top themes 
themes <- names(freqs)[1:15]
counts <- freqs[1:15]

# View results
data.frame(theme=themes, count=counts)


# Inspect frequent terms
findFreqTerms(dtm_thrive, lowfreq=10)

# Run LDA topic modeling
topics_thrive <- LDA(dtm_thrive, k=15)
topics_thrive

# View top terms in each topic
terms <- topics_thrive@terms
for(i in 1:15){
  print(terms[i])
}

# Assign topics to documents
topic_distribution <- topics_thrive@gamma  
thrive_data$topic <- apply(topic_distribution, 1, which.max)

# Tabulate topics
table(thrive_data$topic)

# Sentiment analysis
library(tidytext)
sentiment <- thrive_data %>% unnest_tokens(word, Response) %>%
  inner_join(get_sentiments("bing")) %>%
  count(topic, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(sentiment = positive - negative)

# Visualize results
library(ggplot2)
ggplot(sentiment, aes(x=topic, y=sentiment)) +
  geom_col()
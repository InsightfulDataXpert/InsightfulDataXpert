# What is the worst imaginable future? - Text Analytics.

install.packages("tm")
install.packages("tokenizers")
install.packages("SnowballC")
install.packages("textstem")
install.packages('gutenbergr')

# Add packages to Library
library(tm)
library(tokenizers)
library(textstem)
library(gutenbergr)

setwd("/Users/srishteesinha/Documents")
getwd()

# Load data
worstfuture_data <- read.csv("WorstFuture.csv", header = TRUE)

docs <- Corpus(VectorSource(worstfuture_data))
?VectorSource
?Corpus
summary(docs)
print(docs[[1]]$content)

# Tokenize
words_token <- tokenize_words(docs$content)
print(words_token[1])

# Convert to lower case.
docs2 <- tm_map(docs, content_transformer(tolower))
print(docs2[[1]]$content)

# Remove stopwords.
docs2 <- tm_map(docs2, removeWords, stopwords("english"))
print(docs2[[1]]$content)

# Stemming and Lemmetization.
text_stem <- tm_map(docs2, stemDocument)
print(text_stem [[1]]$content)

text_lemma <- tm_map(docs2, lemmatize_strings)
print(text_lemma[[1]]$content)

print(docs[[1]]$content)

# Term frequency = number of occurrences of a word/ Total no of words.
# DTM - Document Term Matrix describes the frequency of terms that occur in a collection
# of documents (corpus).

dtm <- DocumentTermMatrix(docs2, control = list(
  removePunctuation = TRUE, removeNumbers = TRUE, 
  stopwords =  TRUE, tolower = TRUE, 
  wordLengths=c(1,Inf)))
dtm
findFreqTerms(dtm,2) # words used more than 2 times (low freq).
?findFreqTerms

dtms <- removeSparseTerms(dtm, 0.99) # Drop the words that appear in less than 1% (Sparsely used terms) of the documents.
dtms
findFreqTerms(dtms)

# Wordcloud
install.packages("wordcloud")
library("wordcloud")
freq = data.frame(sort(colSums(as.matrix(dtm)), decreasing=TRUE))
wordcloud(rownames(freq), freq[,1], max.words=50, colors=brewer.pal(1, "Dark2"))
?wordcloud

# Term freq - Inverse document freq.
# term that are common within a document and that are
# rare across documents has higher importance.
dtmtfidf <- DocumentTermMatrix(platocorpus,
                               control = list( weighting =  weightTfIdf, removePunctuation = TRUE, removeNumbers = TRUE, stopwords =  TRUE, 
                                               tolower = TRUE, wordLengths=c(1,Inf)))

freq = data.frame(sort(colSums(as.matrix(dtmtfidf)), decreasing=TRUE))
wordcloud(rownames(freq), freq[,1], max.words=50, colors=brewer.pal(1, "Dark2"))
freq
#==========================End======================================